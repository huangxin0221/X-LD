#' @title Scalable computing for complex LD spectra across species
#' @description Methods to efficiently calculate complex LD patterns for small sample sizes.
#' @param input Specify the genotype files along with the path in PLINK binary format.
#' @param output The output prefix along with the path where the results will be stored.
#' @param maf Filters out all variants with minor allele frequency below the provided threshold (default 0.05)
#' @param geno Filters out all variants with missing call rates exceeding the provided value (default 0.2)
#' @param autosome Excludes all unplaced and non-autosomal variants (default 22)
#' @param population_type Specify the population type (default outbred). If the population is inbred, such as Arabidopsis or rice, please select inbred.
#' @param memory  Set size, in MiB, of initial workspace malloc (default 10000)
#' @param threads Specify the number of threads on which the program will be running (default 1).
#'
#' @export
#' @import utils stats ggplot2

X_LD <- function(input=NULL,
                 output=NULL,
                 population_type=c("outbred","inbred"),
                 maf=0.05,
                 geno=0.2,
                 autosome=22,
                 memory=10000,
                 threads=1){
  #  Check inputs
  if(!(file.exists(paste0(input,".bed"))))
    stop("The bed file doesn't exist.")
  if(!(file.exists(paste0(input,".bim"))))
    stop("The bim file doesn't exist.")
  if(!(file.exists(paste0(input,".fam"))))
    stop("The fam file doesn't exist.")

  if(is.null(output))
    stop("output is NULL")

  if(maf > 0.5 || maf < 0)
    stop("MAF must be >= 0 & <= 0.5")

  if(geno > 1 || geno < 0)
    stop("Missing call rates must be >= 0 & <= 1")

  if(trunc(autosome)-autosome !=0 || autosome < 0)
    stop("autosome number should be a single positive integer")
  if(trunc(memory)-memory !=0 || memory < 0)
    stop("memory should be a single positive integer")
  if(trunc(threads)-threads !=0 || threads < 0)
    stop("threads should be a single positive integer")

  population_type <- match.arg(population_type )

  options (warn = -1)
  # Detect software
  pkg_dir <- find.package("XLD")
  exe_path <- paste0(pkg_dir,"/exec/")
  zip::unzip(paste0(exe_path,"plink2.zip"),overwrite=T,exdir=exe_path)
  if(length(grep("linux",utils::sessionInfo()$platform, ignore.case = TRUE))>0) {
    system(paste0("chmod a+x ",exe_path,"plink2_linux"))
    plink2 = paste0(exe_path,"plink2_linux")
  } else if(length(grep("apple",utils::sessionInfo()$platform, ignore.case = TRUE))>0) {
    system(paste0("chmod a+x ",exe_path,"plink2_mac"))
    plink2 = paste0(exe_path,"plink2_mac")
  } else {
    system(paste0("chmod a+x ",exe_path,"plink2_win.exe"))
    plink2 = paste0(exe_path,"plink2_win.exe")
  }

  if(population_type=="inbred"){
    sc = 2
  }else if(population_type=="outbred"){
    sc = 1
  }
  # Quality control
  cat("QC...\nExtract autosome SNP variants...\n\n")
  QC1 = paste0(plink2, " --bfile ", input, " --chr-set ", autosome, " --allow-extra-chr --set-missing-var-ids @:# --autosome --snps-only --threads ",
               threads, " --memory ",memory , " --make-bed --out ", output,".1.autosome.snp")
  system(QC1)

  cat("\nQC...\nMAF and missing call rates...\n\n")
  QC2 = paste0(plink2, " --bfile ", output, ".1.autosome.snp --chr-set ", autosome, " --maf ", maf, " --geno ", geno, " --threads ",
               threads, " --memory ",memory , " --make-bed --out ", output,".3.core")
  system(QC2)

  # Output files
  chrLD <- data.frame(matrix(NA,nrow=autosome*(autosome+1)/2,ncol=7))
  colnames(chrLD) <- c("chri","chrj","marker number","LD","var(LD)","SE(LD)","p")
  tmp <- rbind(cbind(c(1:autosome),c(1:autosome)),t(combn(autosome,2)))
  chrLD[,c(1,2)] <- tmp[order(tmp[,1],tmp[,2]),]

  # make grm
  nIND <- nrow(read.table(paste0(output, ".3.core.fam"), as.is = T, header = F, colClasses = c("character","NULL","NULL","NULL","NULL","NULL")))
  nSNP <- nrow(read.table(paste0(output, ".3.core.bim"), as.is = T, header=F, colClasses = c("character","NULL","NULL","NULL","NULL","NULL")))

  offDiag <- data.frame(matrix(NA,nrow=nIND*(nIND-1)/2,ncol=autosome))
  bimfile <- read.table(paste0(output, ".3.core.bim"), as.is = T, header = F, colClasses = c("character","NULL","NULL","NULL","NULL","NULL"))

  for(k in 1:autosome){
    nchrSNP <- length(which(bimfile[,1]==k))
    nchrSNP <- as.numeric(nchrSNP)
    if(nchrSNP==0){
      chrLD[which(chrLD$chri==k & chrLD$chrj==k),3] <- NA
      next
    }else{
      chrLD[which(chrLD$chri==k & chrLD$chrj==k),3] <- nchrSNP
      GRM <- paste0(plink2, " --bfile ",output,".3.core --chr ",k," --chr-set ",autosome," --allow-extra-chr --allow-no-sex --make-grm-bin --threads ",
                   threads, " --memory ",memory  ," --out ",output,".chr",k)
      system(GRM)

      grm <- ReadGRMBin(paste0(output,".chr",k))
      offDiag[,k] = (grm$off)/sc

    }
  }
  # Intra-chromosomal LD
  for(k in 1:autosome){
    if(is.na(chrLD[which(chrLD$chri==k & chrLD$chrj==k),3])){
      next
    }else{
      nchrkSNP <- chrLD[which(chrLD$chri==k & chrLD$chrj==k),3]
      offDiagk <- offDiag[,k]

      chrLD[which(chrLD$chri==k & chrLD$chrj==k),4] <- mean(offDiagk^2,na.rm=TRUE)

      if(chrLD[which(chrLD$chri==k & chrLD$chrj==k),4] > 1){
        chrLD[which(chrLD$chri==k & chrLD$chrj==k),4] <- 1
      }
      if(chrLD[which(chrLD$chri==k & chrLD$chrj==k),4] < 0){
        chrLD[which(chrLD$chri==k & chrLD$chrj==k),4] <- 1e-300
      }

      # variance
      chrLD[which(chrLD$chri==k & chrLD$chrj==k),5] <- 4*(var(offDiagk,na.rm=TRUE))^2/(nIND*(nIND-1))

      # SE
      chrLD[which(chrLD$chri==k & chrLD$chrj==k),6] <- sqrt(chrLD[which(chrLD$chri==k & chrLD$chrj==k),5])/sqrt(nIND*(nIND-1)/2)

      # p value
      chrLD[which(chrLD$chri==k & chrLD$chrj==k),7] <- 2*(1-pnorm(chrLD[which(chrLD$chri==k & chrLD$chrj==k),4]/chrLD[which(chrLD$chri==k &chrLD$chrj==k),6]))
    }
    # inter-chromosomal LD
    for(l in 1:autosome){
      if(is.na(chrLD[which(chrLD$chri==l & chrLD$chrj==l),3])){
        next
      }else{
        if(k < l){
          nchrlSNP <- chrLD[which(chrLD$chri==l & chrLD$chrj==l),3]
          chrLD[which(chrLD$chri==k & chrLD$chrj==l),3] <- nchrkSNP + nchrlSNP
          offDiagl = offDiag[,l]

          chrLD[which(chrLD$chri==k & chrLD$chrj==l),4] <- mean(offDiagk*offDiagl,na.rm=TRUE)

          if(chrLD[which(chrLD$chri==k & chrLD$chrj==l),4] > 1){
            chrLD[which(chrLD$chri==k & chrLD$chrj==l),4] <- 1
          }

          if(chrLD[which(chrLD$chri==k & chrLD$chrj==l),4] < 0){
            chrLD[which(chrLD$chri==k & chrLD$chrj==l),4] <- 1e-300
          }

          # variance
          chrLD[which(chrLD$chri==k & chrLD$chrj==l),5] <- 2*(var(offDiagk,na.rm=TRUE)*var(offDiagl,na.rm=TRUE)+
                                                           (chrLD[which(chrLD$chri==k & chrLD$chrj==l),4]-(1/(nIND-1))^2)^2)/(nIND*(nIND-1))

          # SE
          chrLD[which(chrLD$chri==k & chrLD$chrj==l),6] <- sqrt(chrLD[which(chrLD$chri==k & chrLD$chrj==l),5])/sqrt(nIND*(nIND-1)/2)

          # p value
          chrLD[which(chrLD$chri==k & chrLD$chrj==l),7] <- 2*(1-pnorm(chrLD[which(chrLD$chri==k & chrLD$chrj==l),4]/chrLD[which(chrLD$chri==k & chrLD$chrj==l),6]))
        }
      }

    }

  }

  chrLD <- na.omit(chrLD)
  write.table(chrLD,file=paste0(output,".X-LD.txt"),quote = FALSE,sep="\t",row.names = FALSE)

  # chromosome level LD (scaled)
  chrLDscaled <- data.frame(matrix(NA,nrow=nrow(chrLD),ncol=7))
  colnames(chrLDscaled) <- c("chri","chrj","marker number","scaled LD","var(scaled LD)","SE(scaled LD)","p")
  chrLDscaled[,1:3] <- chrLD[,1:3]

  for(k in 1:autosome){
    if(length(chrLDscaled[which(chrLDscaled$chri==k & chrLDscaled$chrj==k),3])==0){
      next
    }else{
      chrLDscaled[which(chrLDscaled$chri==k & chrLDscaled$chrj==k),4] <- 1
      chrLDscaled[which(chrLDscaled$chri==k & chrLDscaled$chrj==k),5:7] <- NA
    }

    for(l in 1:autosome){
      if(length(chrLDscaled[which(chrLDscaled$chri==l & chrLDscaled$chrj==5),l])==0){
        next
      }else{
        if(k < l){
          chrkLD <- chrLD[which(chrLD$chri==k & chrLD$chrj==k),4]
          chrlLD <- chrLD[which(chrLD$chri==l & chrLD$chrj==l),4]
          chrklLD <- chrLD[which(chrLD$chri==k & chrLD$chrj==l),4]

          chrLDscaled[which(chrLDscaled$chri==k & chrLDscaled$chrj==l),4] <- chrklLD/(sqrt(chrkLD)*sqrt(chrlLD))

          d1 <- (chrkLD-(1/(nIND-1))^2)*(chrlLD-(1/(nIND-1))^2)
          d2 <- (chrklLD-1/((nIND-1)^2))^2
          # var
          chrLDscaled[which(chrLDscaled$chri==k & chrLDscaled$chrj==l),5] <- (2*(chrLDscaled[which(chrLDscaled$chri==k & chrLDscaled$chrj==l),4])^2/(nIND*(nIND-1)))*(-2+d1/d2+2*d2/d1)

          # SE
          chrLDscaled[which(chrLDscaled$chri==k & chrLDscaled$chrj==l),6] <- sqrt(chrLDscaled[which(chrLDscaled$chri==k & chrLDscaled$chrj==l),5])/sqrt(nIND*(nIND-1)/2)

          # pval
          chrLDscaled[which(chrLDscaled$chri==k & chrLDscaled$chrj==l),7] <- 2*(1-pnorm(chrLDscaled[which(chrLDscaled$chri==k & chrLDscaled$chrj==l),4]/chrLDscaled[which(chrLDscaled$chri==k & chrLDscaled$chrj==l),6]))

        }
      }
    }

  }

  write.table(chrLDscaled[,1:7],file=paste0(output,".X-LD-Scaled.txt"),quote = FALSE,sep="\t",row.names = FALSE)
  # Visulation
    # unscaled
  logchrLD <- data.frame(cbind(paste0("chr",chrLD[,1]),paste0("chr",chrLD[,2]),chrLD[,3],-log10(chrLD[,4]),chrLD[,7]))
  logchrLD[,3] <- as.numeric(logchrLD[,3])
  logchrLD[,4] <- as.numeric(logchrLD[,4])
  logchrLD[,5] <- as.numeric(logchrLD[,5])
  colnames(logchrLD)[1:5] <- c("chri","chrj","marker number","-log10LD","p")

  p0.01 <- 0.01/nrow(logchrLD)
  p0.05 <- 0.05/nrow(logchrLD)

  logchrLD[which(logchrLD$p <= p0.01),6] <- "**"
  logchrLD[which(logchrLD$p > p0.01 && logchrLD$p <= p0.05),6] <- "*"
  logchrLD[which(logchrLD$p > p0.05),6] <- ""

  MAX <- as.numeric(max(logchrLD[,4]))
  MIN <- as.numeric(min(logchrLD[,4]))
  MID <- (MAX+MIN)/2

  p <- ggplot(data = logchrLD, aes(logchrLD[,2], logchrLD[,1], fill = logchrLD[,4]))+
              geom_tile(color = "white")+
              scale_fill_gradient2(low = "#FF0000", high = "#FFFFFF", mid = "#FF9E81",space = "Lab",
                                   midpoint = MID, limit = c(MIN,MAX),name=expression(paste(-log[10],"LD"))) +
              geom_text(aes(label=logchrLD[,6]),col ="black",family="serif") +
              theme_minimal()+
              scale_y_discrete(position = "right") +
              theme(
                axis.title.x = element_blank(),
                axis.text.x = element_text(angle = 90,family="serif"),
                axis.title.y = element_blank(),
                axis.text.y  = element_text(family="serif"),
                panel.grid.major = element_blank(),
                panel.border = element_blank(),
                panel.background = element_blank(),
                axis.ticks = element_blank(),
                legend.text = element_text(family="serif"),
                legend.title = element_text(family="serif"),
                legend.justification = c(1, 0),
                legend.position = c(0.6, 0.7),
                legend.direction = "horizontal")+
              guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                     title.position = "top", title.hjust = 0.5)) +
              coord_fixed()
  ggsave(paste0(output,".X-LD.pdf"),p,width=8,height=8)

    # scaled
  p0.01 <- 0.01/nrow(na.omit(chrLDscaled))
  p0.05 <- 0.05/nrow(na.omit(chrLDscaled))

  chrLDscaled[which(chrLDscaled$p <= p0.01),8] <- "**"
  chrLDscaled[which(chrLDscaled$p > p0.01 && chrLDscaled$p <= p0.05),8] <- "*"
  chrLDscaled[which(chrLDscaled$p > p0.05 | is.na(chrLDscaled$p)),8] <- ""

  chrLDscaled[,1:2] <- logchrLD[,1:2]
  chrLDscaled[,4] <- as.numeric(chrLDscaled[,4])
  p <- ggplot(data = chrLDscaled, aes(chrLDscaled[,2], chrLDscaled[,1], fill = chrLDscaled[,4]))+
       geom_tile(color = "white")+
       scale_fill_gradient2(low = "#FFFFFF", high = "#FF0000",mid = "#FF9E81",
                            midpoint = 0.5, limit = c(0,1), space = "Lab",
                            name="LD (scaled)") +
       geom_text(aes(label=chrLDscaled[,8]),col ="black",family="serif") +
       theme_minimal()+
       scale_y_discrete(position = "right") +
       theme(
            axis.title.x = element_blank(),
            axis.text.x = element_text(angle = 90,family="serif"),
            axis.title.y = element_blank(),
            axis.text.y = element_text(family="serif"),
            panel.grid.major = element_blank(),
            panel.border = element_blank(),
            panel.background = element_blank(),
            axis.ticks = element_blank(),
            legend.text = element_text(family="serif"),
            legend.title = element_text(family="serif"),
            legend.justification = c(1, 0),
            legend.position = c(0.6, 0.7),
            legend.direction = "horizontal")+
        guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
               title.position = "top", title.hjust = 0.5)) +
        coord_fixed()
  ggsave(paste0(output,".X-LD-Scaled.pdf"),p,width=8,height=8)
}
